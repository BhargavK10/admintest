import 'package:flutter/material.dart';
import 'package:responsive_framework/responsive_framework.dart';
import '../widgets/admin_app_bar.dart';
import '../models/user.dart';

class UsersScreen extends StatefulWidget {
  const UsersScreen({super.key});

  @override
  State<UsersScreen> createState() => _UsersScreenState();
}

class _UsersScreenState extends State<UsersScreen> {
  final TextEditingController _searchController = TextEditingController();
  List<User> _users = [];
  List<User> _filteredUsers = [];
  UserStatus? _statusFilter;

  @override
  void initState() {
    super.initState();
    _loadUsers();
    _searchController.addListener(_filterUsers);
  }

  void _loadUsers() {
    // Mock data - replace with actual data source
    _users = [
      User(
        id: '1',
        name: 'John Doe',
        email: 'john@example.com',
        phone: '+1 234 567 8901',
        createdAt: DateTime.now().subtract(const Duration(days: 30)),
        lastLoginAt: DateTime.now().subtract(const Duration(hours: 2)),
        status: UserStatus.active,
        totalOrders: 15,
        totalSpent: 2450.75,
      ),
      User(
        id: '2',
        name: 'Jane Smith',
        email: 'jane@example.com',
        phone: '+1 234 567 8902',
        createdAt: DateTime.now().subtract(const Duration(days: 45)),
        lastLoginAt: DateTime.now().subtract(const Duration(days: 5)),
        status: UserStatus.active,
        totalOrders: 8,
        totalSpent: 890.25,
      ),
      User(
        id: '3',
        name: 'Mike Johnson',
        email: 'mike@example.com',
        createdAt: DateTime.now().subtract(const Duration(days: 15)),
        lastLoginAt: DateTime.now().subtract(const Duration(days: 10)),
        status: UserStatus.blocked,
        totalOrders: 3,
        totalSpent: 156.50,
      ),
      User(
        id: '4',
        name: 'Sarah Wilson',
        email: 'sarah@example.com',
        phone: '+1 234 567 8904',
        createdAt: DateTime.now().subtract(const Duration(days: 3)),
        lastLoginAt: DateTime.now().subtract(const Duration(days: 3)),
        status: UserStatus.pending,
        totalOrders: 0,
        totalSpent: 0.0,
      ),
      User(
        id: '5',
        name: 'David Brown',
        email: 'david@example.com',
        createdAt: DateTime.now().subtract(const Duration(days: 60)),
        lastLoginAt: DateTime.now().subtract(const Duration(hours: 1)),
        status: UserStatus.active,
        totalOrders: 25,
        totalSpent: 5200.00,
      ),
    ];
    _filteredUsers = List.from(_users);
  }

  void _filterUsers() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredUsers = _users.where((user) {
        final matchesSearch = user.name.toLowerCase().contains(query) ||
                             user.email.toLowerCase().contains(query);
        final matchesStatus = _statusFilter == null || user.status == _statusFilter;
        return matchesSearch && matchesStatus;
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDesktop = ResponsiveBreakpoints.of(context).largerThan(TABLET);
    
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surfaceContainerLowest,
      appBar: const AdminAppBar(title: 'Users Management'),
      body: ResponsiveScaledBox(
        width: ResponsiveValue<double>(
          context,
          conditionalValues: [
            const Condition.equals(name: DESKTOP, value: 1200),
            const Condition.equals(name: TABLET, value: 800),
          ],
          defaultValue: 450,
        ).value,
        child: Padding(
          padding: EdgeInsets.all(isDesktop ? 32.0 : 16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header
              Text(
                'User Management',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 24),
              
              // Search and Filter Row
              ResponsiveRowColumn(
                layout: isDesktop ? ResponsiveRowColumnType.ROW : ResponsiveRowColumnType.COLUMN,
                rowSpacing: 16,
                columnSpacing: 16,
                children: [
                  ResponsiveRowColumnItem(
                    rowFlex: 2,
                    child: Card(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: TextField(
                          controller: _searchController,
                          decoration: const InputDecoration(
                            hintText: 'Search users...',
                            prefixIcon: Icon(Icons.search),
                            border: InputBorder.none,
                          ),
                        ),
                      ),
                    ),
                  ),
                  ResponsiveRowColumnItem(
                    rowFlex: 1,
                    child: Card(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: DropdownButton<UserStatus?>(
                          value: _statusFilter,
                          isExpanded: true,
                          underline: const SizedBox(),
                          hint: const Text('Filter by status'),
                          items: [
                            const DropdownMenuItem<UserStatus?>(
                              value: null,
                              child: Text('All Statuses'),
                            ),
                            ...UserStatus.values.map(
                              (status) => DropdownMenuItem<UserStatus?>(
                                value: status,
                                child: Text(status.displayName),
                              ),
                            ),
                          ],
                          onChanged: (value) {
                            setState(() {
                              _statusFilter = value;
                            });
                            _filterUsers();
                          },
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              
              // Users List
              Expanded(
                child: _filteredUsers.isEmpty
                    ? _buildEmptyState()
                    : isDesktop
                        ? _buildDataTable()
                        : _buildUserCards(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.people_outline,
            size: 64,
            color: Theme.of(context).colorScheme.onSurfaceVariant,
          ),
          const SizedBox(height: 16),
          Text(
            'No users found',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDataTable() {
    return Card(
      child: SingleChildScrollView(
        child: DataTable(
          columns: const [
            DataColumn(label: Text('User')),
            DataColumn(label: Text('Contact')),
            DataColumn(label: Text('Status')),
            DataColumn(label: Text('Orders')),
            DataColumn(label: Text('Total Spent')),
            DataColumn(label: Text('Last Login')),
            DataColumn(label: Text('Actions')),
          ],
          rows: _filteredUsers.map((user) {
            return DataRow(
              cells: [
                DataCell(
                  Row(
                    children: [
                      CircleAvatar(
                        backgroundColor: Theme.of(context).colorScheme.primary,
                        child: Text(
                          user.name[0].toUpperCase(),
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            user.name,
                            style: const TextStyle(fontWeight: FontWeight.w500),
                          ),
                          Text(
                            user.email,
                            style: TextStyle(
                              fontSize: 12,
                              color: Theme.of(context).colorScheme.onSurfaceVariant,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                DataCell(Text(user.phone ?? 'N/A')),
                DataCell(_buildStatusChip(user.status)),
                DataCell(Text('${user.totalOrders}')),
                DataCell(Text('\$${user.totalSpent.toStringAsFixed(2)}')),
                DataCell(Text(_formatDate(user.lastLoginAt))),
                DataCell(
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        onPressed: () => _viewUserDetails(user),
                        icon: const Icon(Icons.visibility),
                        tooltip: 'View Details',
                      ),
                      IconButton(
                        onPressed: () => _toggleUserStatus(user),
                        icon: Icon(
                          user.status == UserStatus.blocked 
                              ? Icons.person_add 
                              : Icons.block,
                        ),
                        tooltip: user.status == UserStatus.blocked 
                            ? 'Unblock User' 
                            : 'Block User',
                      ),
                    ],
                  ),
                ),
              ],
            );
          }).toList(),
        ),
      ),
    );
  }

  Widget _buildUserCards() {
    return ListView.builder(
      itemCount: _filteredUsers.length,
      itemBuilder: (context, index) {
        final user = _filteredUsers[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    CircleAvatar(
                      backgroundColor: Theme.of(context).colorScheme.primary,
                      child: Text(
                        user.name[0].toUpperCase(),
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            user.name,
                            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            user.email,
                            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: Theme.of(context).colorScheme.onSurfaceVariant,
                            ),
                          ),
                          if (user.phone != null)
                            Text(
                              user.phone!,
                              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                color: Theme.of(context).colorScheme.onSurfaceVariant,
                              ),
                            ),
                        ],
                      ),
                    ),
                    PopupMenuButton<String>(
                      onSelected: (value) {
                        if (value == 'view') {
                          _viewUserDetails(user);
                        } else if (value == 'toggle') {
                          _toggleUserStatus(user);
                        }
                      },
                      itemBuilder: (context) => [
                        const PopupMenuItem(
                          value: 'view',
                          child: Row(
                            children: [
                              Icon(Icons.visibility),
                              SizedBox(width: 8),
                              Text('View Details'),
                            ],
                          ),
                        ),
                        PopupMenuItem(
                          value: 'toggle',
                          child: Row(
                            children: [
                              Icon(
                                user.status == UserStatus.blocked 
                                    ? Icons.person_add 
                                    : Icons.block,
                              ),
                              const SizedBox(width: 8),
                              Text(
                                user.status == UserStatus.blocked 
                                    ? 'Unblock User' 
                                    : 'Block User',
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    _buildStatusChip(user.status),
                    const Spacer(),
                    Text(
                      'Last login: ${_formatDate(user.lastLoginAt)}',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: _buildStatContainer(
                        'Orders',
                        '${user.totalOrders}',
                        Icons.shopping_bag,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _buildStatContainer(
                        'Total Spent',
                        '\$${user.totalSpent.toStringAsFixed(2)}',
                        Icons.attach_money,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildStatContainer(String label, String value, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Icon(icon, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                Text(
                  value,
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusChip(UserStatus status) {
    Color backgroundColor;
    Color textColor;
    
    switch (status) {
      case UserStatus.active:
        backgroundColor = Colors.green.withOpacity(0.1);
        textColor = Colors.green;
        break;
      case UserStatus.blocked:
        backgroundColor = Colors.red.withOpacity(0.1);
        textColor = Colors.red;
        break;
      case UserStatus.pending:
        backgroundColor = Colors.orange.withOpacity(0.1);
        textColor = Colors.orange;
        break;
    }
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        status.displayName,
        style: TextStyle(
          color: textColor,
          fontWeight: FontWeight.w500,
          fontSize: 12,
        ),
      ),
    );
  }

  void _viewUserDetails(User user) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('User Details - ${user.name}'),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildDetailRow('Name', user.name),
              _buildDetailRow('Email', user.email),
              _buildDetailRow('Phone', user.phone ?? 'N/A'),
              _buildDetailRow('Status', user.status.displayName),
              _buildDetailRow('Total Orders', '${user.totalOrders}'),
              _buildDetailRow('Total Spent', '\$${user.totalSpent.toStringAsFixed(2)}'),
              _buildDetailRow('Member Since', _formatDate(user.createdAt)),
              _buildDetailRow('Last Login', _formatDate(user.lastLoginAt)),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  void _toggleUserStatus(User user) {
    final newStatus = user.status == UserStatus.blocked 
        ? UserStatus.active 
        : UserStatus.blocked;
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('${newStatus == UserStatus.blocked ? 'Block' : 'Unblock'} User'),
        content: Text(
          'Are you sure you want to ${newStatus == UserStatus.blocked ? 'block' : 'unblock'} ${user.name}?'
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              setState(() {
                user.status = newStatus;
              });
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    '${user.name} has been ${newStatus == UserStatus.blocked ? 'blocked' : 'unblocked'}',
                  ),
                ),
              );
            },
            child: Text(newStatus == UserStatus.blocked ? 'Block' : 'Unblock'),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 100,
            child: Text(
              '$label:',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);
    
    if (difference.inDays > 0) {
      return '${difference.inDays}d ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inMinutes}m ago';
    }
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
}