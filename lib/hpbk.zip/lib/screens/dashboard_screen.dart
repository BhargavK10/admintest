import 'package:flutter/material.dart';
import 'package:responsive_framework/responsive_framework.dart';
import '../widgets/dashboard_card.dart';
import '../widgets/admin_app_bar.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final isDesktop = ResponsiveBreakpoints.of(context).largerThan(TABLET);
    final isTablet = ResponsiveBreakpoints.of(context).equals(TABLET);
    
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surfaceContainerLowest,
      appBar: const AdminAppBar(title: 'Admin Dashboard'),
      body: ResponsiveScaledBox(
        width: ResponsiveValue<double>(
          context,
          conditionalValues: [
            const Condition.equals(name: DESKTOP, value: 1200),
            const Condition.equals(name: TABLET, value: 800),
          ],
          defaultValue: 450,
        ).value,
        child: SingleChildScrollView(
          padding: EdgeInsets.all(isDesktop ? 32.0 : 16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Welcome Section
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Theme.of(context).colorScheme.primary,
                      Theme.of(context).colorScheme.primary.withOpacity(0.8),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Welcome back, Admin!',
                      style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Manage your application with ease',
                      style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                        color: Colors.white.withOpacity(0.9),
                      ),
                    ),
                  ],
                ),
              ),
              
              const SizedBox(height: 32),
              
              // Quick Stats
              Text(
                'Quick Overview',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              
              ResponsiveRowColumn(
                layout: isDesktop ? ResponsiveRowColumnType.ROW : ResponsiveRowColumnType.COLUMN,
                rowSpacing: 16,
                columnSpacing: 16,
                children: [
                  ResponsiveRowColumnItem(
                    rowFlex: 1,
                    child: _buildStatCard(
                      context,
                      'Total Orders',
                      '1,234',
                      Icons.shopping_cart,
                      Colors.blue,
                    ),
                  ),
                  ResponsiveRowColumnItem(
                    rowFlex: 1,
                    child: _buildStatCard(
                      context,
                      'Products',
                      '567',
                      Icons.inventory,
                      Colors.green,
                    ),
                  ),
                  ResponsiveRowColumnItem(
                    rowFlex: 1,
                    child: _buildStatCard(
                      context,
                      'Users',
                      '2,890',
                      Icons.people,
                      Colors.orange,
                    ),
                  ),
                  ResponsiveRowColumnItem(
                    rowFlex: 1,
                    child: _buildStatCard(
                      context,
                      'Categories',
                      '45',
                      Icons.category,
                      Colors.purple,
                    ),
                  ),
                ],
              ),
              
              const SizedBox(height: 32),
              
              // Modules Section
              Text(
                'Management Modules',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              
              // Modules Grid
              _buildModulesGrid(context, isDesktop, isTablet),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatCard(BuildContext context, String title, String value, IconData icon, Color color) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    value,
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildModulesGrid(BuildContext context, bool isDesktop, bool isTablet) {
    final crossAxisCount = isDesktop ? 4 : (isTablet ? 3 : 2);
    
    final modules = [
      {
        'title': 'Contact',
        'subtitle': 'View contact submissions',
        'icon': Icons.contact_mail,
        'route': '/contact',
        'color': const Color(0xFF3B82F6),
      },
      {
        'title': 'Orders',
        'subtitle': 'Manage orders & status',
        'icon': Icons.shopping_bag,
        'route': '/orders',
        'color': const Color(0xFF10B981),
      },
      {
        'title': 'Add Category',
        'subtitle': 'Create new categories',
        'icon': Icons.add_box,
        'route': '/add-category',
        'color': const Color(0xFF8B5CF6),
      },
      {
        'title': 'Category List',
        'subtitle': 'Manage categories',
        'icon': Icons.category,
        'route': '/category-list',
        'color': const Color(0xFFF59E0B),
      },
      {
        'title': 'Add Product',
        'subtitle': 'Add new products',
        'icon': Icons.add_shopping_cart,
        'route': '/add-product',
        'color': const Color(0xFFEF4444),
      },
      {
        'title': 'Product List',
        'subtitle': 'Manage products',
        'icon': Icons.inventory_2,
        'route': '/product-list',
        'color': const Color(0xFF06B6D4),
      },
      {
        'title': 'Users',
        'subtitle': 'Manage users',
        'icon': Icons.people,
        'route': '/users',
        'color': const Color(0xFF84CC16),
      },
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: crossAxisCount,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
        childAspectRatio: isDesktop ? 1.2 : 1.1,
      ),
      itemCount: modules.length,
      itemBuilder: (context, index) {
        final module = modules[index];
        return DashboardCard(
          title: module['title'] as String,
          subtitle: module['subtitle'] as String,
          icon: module['icon'] as IconData,
          color: module['color'] as Color,
          onTap: () => Navigator.pushNamed(context, module['route'] as String),
        );
      },
    );
  }
}