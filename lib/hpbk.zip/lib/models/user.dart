enum UserStatus {
  active('Active'),
  blocked('Blocked'),
  pending('Pending');

  const UserStatus(this.displayName);
  final String displayName;
}

class User {
  final String id;
  final String name;
  final String email;
  final String? phone;
  final DateTime createdAt;
  final DateTime lastLoginAt;
  UserStatus status;
  final String? avatar;
  final int totalOrders;
  final double totalSpent;

  User({
    required this.id,
    required this.name,
    required this.email,
    this.phone,
    required this.createdAt,
    required this.lastLoginAt,
    required this.status,
    this.avatar,
    this.totalOrders = 0,
    this.totalSpent = 0.0,
  });

  User copyWith({
    String? id,
    String? name,
    String? email,
    String? phone,
    DateTime? createdAt,
    DateTime? lastLoginAt,
    UserStatus? status,
    String? avatar,
    int? totalOrders,
    double? totalSpent,
  }) {
    return User(
      id: id ?? this.id,
      name: name ?? this.name,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      createdAt: createdAt ?? this.createdAt,
      lastLoginAt: lastLoginAt ?? this.lastLoginAt,
      status: status ?? this.status,
      avatar: avatar ?? this.avatar,
      totalOrders: totalOrders ?? this.totalOrders,
      totalSpent: totalSpent ?? this.totalSpent,
    );
  }
}