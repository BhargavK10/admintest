enum OrderStatus {
  pending('Pending'),
  shipped('Shipped'),
  delivered('Delivered'),
  cancelled('Cancelled');

  const OrderStatus(this.displayName);
  final String displayName;
}

class Order {
  final String id;
  final String customerName;
  final String customerEmail;
  final double amount;
  OrderStatus status;
  final DateTime createdAt;
  final List<OrderItem> items;

  Order({
    required this.id,
    required this.customerName,
    required this.customerEmail,
    required this.amount,
    required this.status,
    required this.createdAt,
    required this.items,
  });
}

class OrderItem {
  final String productId;
  final String productName;
  final int quantity;
  final double price;

  OrderItem({
    required this.productId,
    required this.productName,
    required this.quantity,
    required this.price,
  });
}