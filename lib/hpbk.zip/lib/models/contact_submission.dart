class ContactSubmission {
  final String id;
  final String name;
  final String email;
  final String subject;
  final String message;
  final DateTime submittedAt;
  bool isRead;

  ContactSubmission({
    required this.id,
    required this.name,
    required this.email,
    required this.subject,
    required this.message,
    required this.submittedAt,
    this.isRead = false,
  });
}